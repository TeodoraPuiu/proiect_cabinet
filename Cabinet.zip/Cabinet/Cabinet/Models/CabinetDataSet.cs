﻿namespace Cabinet.Models
{


    partial class CabinetDataSet
    {
        partial class ProgramInterDataTable
        {
        }
    }
}
